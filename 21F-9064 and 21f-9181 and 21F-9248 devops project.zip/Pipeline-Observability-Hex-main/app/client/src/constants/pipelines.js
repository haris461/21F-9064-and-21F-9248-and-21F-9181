export const pieplines = [
  {
    name: "Pipeline Observability Hex",
    executions: "3",
    failures: "1",
    median: "1 min 28 s",
    last_build: "Success",
  },
  {
    name: "FYP Pipeline",
    executions: "2",
    failures: "0",
    median: "1 min 2 s",
    last_build: "Failed",
  },
  {
    name: "Alpine Node Pipeline",
    executions: "5",
    failures: "0",
    median: "28 s",
    last_build: "Success",
  },
];
