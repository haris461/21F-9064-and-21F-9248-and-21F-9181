import Pipelines from "@/components/organisms/Dashboard/Pipelines";

const Page = () => {
  return (
  <Pipelines />
  );
};

export default Page;
