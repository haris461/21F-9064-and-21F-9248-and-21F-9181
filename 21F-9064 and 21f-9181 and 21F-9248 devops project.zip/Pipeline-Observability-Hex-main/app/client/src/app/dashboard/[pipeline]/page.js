import Dashboard from "@/components/organisms/Dashboard";

const page = () => {
  return (
      <Dashboard/>
  );
};

export default page;
