import Settings from '@/components/organisms/Settings/Settings'
import React from 'react'

const page = () => {
  return (
    <Settings/>
  )
}

export default page