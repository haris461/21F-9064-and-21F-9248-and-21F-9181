import ResetPassword from "@/components/organisms/ResetPassword"

const page = () => {
  return (
    <ResetPassword/>
  )
}

export default page