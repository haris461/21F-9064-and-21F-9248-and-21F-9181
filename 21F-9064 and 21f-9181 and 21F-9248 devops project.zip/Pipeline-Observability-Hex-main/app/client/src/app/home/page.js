import DashboardLayout from "../dashboard/layout";
import Home from "@/components/organisms/Dashboard/Home";

const page = () => {
  return (
    <DashboardLayout>
    <Home/>
    </DashboardLayout>
  );
};

export default page;
