import LandingPage from '@/components/organisms/LandingPage'
import React from 'react'

const page = () => {
  return (
    <LandingPage/>
  )
}

export default page