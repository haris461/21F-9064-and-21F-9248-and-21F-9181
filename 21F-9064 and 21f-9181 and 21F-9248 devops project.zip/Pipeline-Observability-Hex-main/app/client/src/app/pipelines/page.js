import Pipelines from '@/components/organisms/Pipelines'
import React from 'react'

const page = () => {
  return (
    <Pipelines/>
  )
}

export default page