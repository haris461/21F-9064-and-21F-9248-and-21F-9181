'use strict';

/**
 * app-icon service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::app-icon.app-icon');
