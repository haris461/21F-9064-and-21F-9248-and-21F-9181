'use strict';

/**
 * app-icon controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::app-icon.app-icon');
