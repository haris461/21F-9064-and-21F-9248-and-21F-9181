'use strict';

/**
 * app-icon router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::app-icon.app-icon');
