'use strict';

/**
 * card-image router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::card-image.card-image');
