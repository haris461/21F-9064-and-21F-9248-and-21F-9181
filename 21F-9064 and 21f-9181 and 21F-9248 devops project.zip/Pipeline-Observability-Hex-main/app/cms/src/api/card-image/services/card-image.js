'use strict';

/**
 * card-image service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::card-image.card-image');
