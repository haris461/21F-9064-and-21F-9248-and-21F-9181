'use strict';

/**
 * siderbar-icon controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::siderbar-icon.siderbar-icon');
