'use strict';

/**
 * siderbar-icon router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::siderbar-icon.siderbar-icon');
