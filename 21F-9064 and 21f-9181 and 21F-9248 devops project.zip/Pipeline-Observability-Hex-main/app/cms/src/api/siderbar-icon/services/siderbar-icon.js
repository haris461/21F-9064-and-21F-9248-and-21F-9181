'use strict';

/**
 * siderbar-icon service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::siderbar-icon.siderbar-icon');
